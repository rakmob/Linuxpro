#include <stdio.h>
test(){
	printf(" test lib\n");
}
