#include <stdio.h>
int main()
{
	printf("calling lib routine\n");
	f1();

	return 0;
}
