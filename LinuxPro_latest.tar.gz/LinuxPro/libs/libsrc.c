# include <stdio.h>

void test()
{
	printf("library test routine invoked\n");
}

int _init()
{
	printf("in library init routine\n");
	return 0;
}

int _fini()
{
	printf("in library fini routine\n");
	return 0;
}
