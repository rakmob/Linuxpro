# include <stdio.h>

void common2()
{
	printf("libb common2\n");
}
void libb()
{
	common2();
}
