# include <stdio.h>

void common1()
{
	printf("liba common1\n");
}
void liba()
{
	common1();
}
