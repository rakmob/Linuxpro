#include <stdio.h>
int main()
{
	liba();
	libb();
	return 0;
}
