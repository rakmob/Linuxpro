#include<stdio.h>

int main()
{
	printf("Welcome to linux world\n");
	printf("pid %d\n",getpid());
	getchar();
	return 0;
}
