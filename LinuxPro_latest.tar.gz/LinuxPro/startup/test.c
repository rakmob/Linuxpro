/* entry point test */
# include <stdio.h>
# include <stdlib.h>

/* program entry point */
int _start()
{
	printf("in start routine\n");
	xyz();
	_fini();
	exit(0);
}
/* start of functionality */
int xyz()
{
	printf("begin of app functionality\n");
	return 0;
}
/* program destructor */
int _fini()
{
	printf("cleanup invoked\n");
	return 0;
}	
