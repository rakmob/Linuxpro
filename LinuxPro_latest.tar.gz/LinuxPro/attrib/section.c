#include<stdio.h>
int * hw_register __attribute__ ((section ("SPECIAL_SECTION")));


int main()
{
	/* do something */
}

