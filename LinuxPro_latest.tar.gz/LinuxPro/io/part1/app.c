
int main()
{

	open("/root/abc");
	open("/media/xyz");
	open("/mnt/abc");
	

}
